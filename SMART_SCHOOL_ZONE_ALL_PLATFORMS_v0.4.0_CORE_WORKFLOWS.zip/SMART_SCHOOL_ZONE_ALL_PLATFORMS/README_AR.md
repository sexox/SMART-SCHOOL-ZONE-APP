# SMART SCHOOL ZONE — حزمة المشروع متعددة المنصات

هذه حزمة مصدر أولية منظمة لتطوير النظام على Android وiOS وWindows مع خادم مركزي.
**ليست هذه الحزمة إصداراً إنتاجياً مكتملاً، ولا تحتوي APK أو EXE أو IPA جاهزاً.**
تُنشأ ملفات المنصات الثنائية عبر GitHub Actions بعد رفع المشروع وضبط بيئة البناء.

## ما الذي تحتويه؟
- `app/`: مشروع Flutter مشترك للهواتف والحاسوب.
- `server/`: هيكل API أولي باستخدام FastAPI.
- `database/`: مخطط PostgreSQL مبدئي للأدوار وطلبات التسجيل والحضور.
- `.github/workflows/`: مسارات بناء Android وWindows وiOS.
- `docs/`: قرارات النظام وتعليمات البناء.

## طريقة الرفع إلى GitHub
1. أنشئ مستودعاً جديداً أو افتح مستودع `SMART-SCHOOL-ZONE`.
2. ارفع محتويات هذا المجلد إلى جذر المستودع، وليس ملف ZIP وحده إذا كنت تريد تشغيل Actions.
3. افتح تبويب **Actions** وفعّل workflows إن طلب GitHub ذلك.
4. شغّل `Build Android`, `Build Windows`, و`Build iOS` من Actions.
5. بعد نجاح كل عملية، نزّل ملف Artifact الخاص بها. يمكن لاحقاً إضافة workflow يجمعها في ZIP موحد.

## متطلبات البناء
- Flutter stable وDart متوافقان مع `app/pubspec.yaml`.
- Android: GitHub-hosted Ubuntu runner.
- Windows: GitHub-hosted Windows runner.
- iOS: macOS runner وXcode. إنشاء IPA موقّع يتطلب إعداد شهادات وملفات provisioning profile وأسرار التوقيع.
- الخادم: Python 3.11+ وPostgreSQL.

## حالة التنفيذ
هذه نقطة انطلاق تقنية وليست ادعاءً باكتمال كل الميزات. الواجهات والـ API والمزامنة وتكامل Google وPush والإدارة تحتاج استكمالاً واختبارات وربطاً فعلياً قبل الاستخدام المدرسي.
