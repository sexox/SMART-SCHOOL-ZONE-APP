# SMART SCHOOL ZONE
Cross-platform Flutter application and central API starter.

See [Arabic setup guide](README_AR.md). This repository is a source scaffold, not a production-ready school management system or a collection of installable binaries.
