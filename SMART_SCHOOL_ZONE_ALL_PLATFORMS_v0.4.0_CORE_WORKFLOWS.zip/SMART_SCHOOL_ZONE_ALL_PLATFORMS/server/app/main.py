import os, sqlite3, secrets, hashlib, hmac, time
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException, Header, UploadFile, File
from pydantic import BaseModel, EmailStr, Field

DB_PATH = os.getenv("SSZ_DB_PATH", "smart_school_zone.db")
FILES_DIR = Path(os.getenv("SSZ_FILES_DIR", "school_files"))
FILES_DIR.mkdir(parents=True, exist_ok=True)
BOOTSTRAP_KEY = os.getenv("SSZ_ADMIN_BOOTSTRAP_KEY", "")
TOKEN_TTL = 60 * 60 * 24 * 14

app = FastAPI(title="SMART SCHOOL ZONE API", version="0.3.0")

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.executescript('''
        CREATE TABLE IF NOT EXISTS schools(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS accounts(
          id INTEGER PRIMARY KEY AUTOINCREMENT, school_id INTEGER NOT NULL,
          display_name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, role TEXT NOT NULL,
          status TEXT NOT NULL, password_hash TEXT NOT NULL, created_at INTEGER NOT NULL,
          FOREIGN KEY(school_id) REFERENCES schools(id)
        );
        CREATE TABLE IF NOT EXISTS link_codes(
          code TEXT PRIMARY KEY, account_id INTEGER NOT NULL, expires_at INTEGER NOT NULL,
          used INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(account_id) REFERENCES accounts(id)
        );
        CREATE TABLE IF NOT EXISTS sessions(
          token_hash TEXT PRIMARY KEY, account_id INTEGER NOT NULL, expires_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS permissions(
          account_id INTEGER NOT NULL, permission TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 0,
          PRIMARY KEY(account_id, permission)
        );
        CREATE TABLE IF NOT EXISTS attendance_events(
          id TEXT PRIMARY KEY, account_id INTEGER NOT NULL, school_id INTEGER NOT NULL,
          event_type TEXT NOT NULL CHECK(event_type IN ('check_in','check_out')),
          device_recorded_at TEXT NOT NULL, server_received_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS synced_files(
          id INTEGER PRIMARY KEY AUTOINCREMENT, school_id INTEGER NOT NULL, owner_id INTEGER NOT NULL,
          filename TEXT NOT NULL, stored_name TEXT NOT NULL, uploaded_at INTEGER NOT NULL
        );
        ''')
init_db()

class RegisterIn(BaseModel):
    display_name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    role: str
    school_name: Optional[str] = ""
    bootstrap_key: Optional[str] = None

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class CodeIn(BaseModel):
    code: str = Field(min_length=6, max_length=16)

class PermissionIn(BaseModel):
    permissions: list[str]

def hash_password(password: str, salt: Optional[bytes] = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310000)
    return salt.hex() + "$" + digest.hex()

def verify_password(password: str, saved: str) -> bool:
    try:
        salt_hex, digest_hex = saved.split("$", 1)
        return hmac.compare_digest(hash_password(password, bytes.fromhex(salt_hex)).split("$", 1)[1], digest_hex)
    except Exception:
        return False

def issue_token(account_id: int) -> str:
    token = secrets.token_urlsafe(36)
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    with db() as con:
        con.execute("INSERT INTO sessions VALUES(?,?,?)", (token_hash, account_id, int(time.time()) + TOKEN_TTL))
    return token

def current_user(authorization: Optional[str]):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "يلزم تسجيل الدخول")
    token = authorization[7:]
    digest = hashlib.sha256(token.encode()).hexdigest()
    with db() as con:
        row = con.execute('''SELECT a.* FROM sessions s JOIN accounts a ON a.id=s.account_id
          WHERE s.token_hash=? AND s.expires_at>?''', (digest, int(time.time()))).fetchone()
    if not row:
        raise HTTPException(401, "الجلسة غير صالحة أو انتهت")
    return row

def admin_user(authorization):
    user = current_user(authorization)
    if user["role"] != "admin" or user["status"] != "active":
        raise HTTPException(403, "هذه العملية للمدير فقط")
    return user

@app.get("/health")
def health():
    return {"status": "ok", "service": "smart-school-zone-api"}

@app.post("/auth/register")
def register(data: RegisterIn):
    if data.role not in {"admin", "teacher", "student", "staff"}:
        raise HTTPException(400, "نوع الحساب غير صحيح")
    now = int(time.time())
    with db() as con:
        exists = con.execute("SELECT id FROM accounts WHERE email=?", (data.email.lower(),)).fetchone()
        if exists:
            raise HTTPException(409, "هذا البريد مسجل مسبقاً")
        if data.role == "admin":
            if not BOOTSTRAP_KEY or not data.bootstrap_key or not hmac.compare_digest(data.bootstrap_key, BOOTSTRAP_KEY):
                raise HTTPException(403, "رمز تهيئة المدير غير صحيح")
            school_name = (data.school_name or "").strip()
            if len(school_name) < 2:
                raise HTTPException(400, "أدخل اسم المدرسة")
            school_id = con.execute("INSERT INTO schools(name,created_at) VALUES(?,?)", (school_name, now)).lastrowid
            cur = con.execute('''INSERT INTO accounts(school_id,display_name,email,role,status,password_hash,created_at)
              VALUES(?,?,?,?,?,?,?)''', (school_id, data.display_name, data.email.lower(), "admin", "active", hash_password(data.password), now))
            account_id = cur.lastrowid
            token = issue_token(account_id)
            return {"status": "active", "access_token": token, "role": "admin"}
        # Non-admin account remains pending and receives a one-time code.
        with db() as con2:
            school = con2.execute("SELECT id FROM schools ORDER BY id LIMIT 1").fetchone()
            if not school:
                raise HTTPException(409, "لم يتم إنشاء مدرسة بعد. يجب أن ينشئ المدير المدرسة أولاً.")
            cur = con2.execute('''INSERT INTO accounts(school_id,display_name,email,role,status,password_hash,created_at)
              VALUES(?,?,?,?,?,?,?)''', (school["id"], data.display_name, data.email.lower(), data.role, "pending", hash_password(data.password), now))
            account_id = cur.lastrowid
            code = secrets.token_hex(4).upper()
            con2.execute("INSERT INTO link_codes(code,account_id,expires_at) VALUES(?,?,?)", (code, account_id, now + 60*60*24*7))
        return {"status": "pending", "link_code": code, "message": "أرسل الكود إلى مدير المدرسة للموافقة"}

@app.post("/auth/login")
def login(data: LoginIn):
    with db() as con:
        row = con.execute("SELECT * FROM accounts WHERE email=?", (data.email.lower(),)).fetchone()
    if not row or not verify_password(data.password, row["password_hash"]):
        raise HTTPException(401, "بيانات الدخول غير صحيحة")
    if row["status"] != "active":
        raise HTTPException(403, "الحساب بانتظار موافقة المدير أو موقوف")
    return {"access_token": issue_token(row["id"]), "role": row["role"], "display_name": row["display_name"]}

@app.post("/admin/approve-code")
def approve_code(data: CodeIn, authorization: Optional[str] = Header(default=None)):
    admin = admin_user(authorization)
    with db() as con:
        row = con.execute('''SELECT lc.*, a.school_id, a.display_name, a.role FROM link_codes lc
          JOIN accounts a ON a.id=lc.account_id WHERE lc.code=? AND lc.used=0 AND lc.expires_at>?''',
          (data.code.upper(), int(time.time()))).fetchone()
        if not row or row["school_id"] != admin["school_id"]:
            raise HTTPException(404, "الكود غير صالح أو لا يتبع مدرستك")
        con.execute("UPDATE accounts SET status='active' WHERE id=?", (row["account_id"],))
        con.execute("UPDATE link_codes SET used=1 WHERE code=?", (data.code.upper(),))
    return {"status": "active", "display_name": row["display_name"], "role": row["role"]}

@app.get("/admin/accounts")
def list_accounts(authorization: Optional[str] = Header(default=None)):
    admin = admin_user(authorization)
    with db() as con:
        rows = con.execute('''SELECT id,display_name,email,role,status,created_at FROM accounts
          WHERE school_id=? ORDER BY created_at DESC''', (admin["school_id"],)).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            perms = con.execute("SELECT permission,enabled FROM permissions WHERE account_id=?", (row["id"],)).fetchall()
            item["permissions"] = {p["permission"]: bool(p["enabled"]) for p in perms}
            result.append(item)
    return {"accounts": result}

@app.put("/admin/accounts/{account_id}/permissions")
def set_permissions(account_id: int, data: PermissionIn, authorization: Optional[str] = Header(default=None)):
    admin = admin_user(authorization)
    allowed = {"attendance.read", "attendance.write", "students.read", "students.manage",
                "reports.read", "reports.export", "files.read", "files.upload", "classes.manage"}
    if any(p not in allowed for p in data.permissions):
        raise HTTPException(400, "توجد صلاحية غير معروفة")
    with db() as con:
        target = con.execute("SELECT id,role FROM accounts WHERE id=? AND school_id=?", (account_id, admin["school_id"])).fetchone()
        if not target or target["role"] == "admin":
            raise HTTPException(404, "الحساب غير موجود أو لا يمكن تعديل صلاحياته")
        con.execute("DELETE FROM permissions WHERE account_id=?", (account_id,))
        con.executemany("INSERT INTO permissions(account_id,permission,enabled) VALUES(?,?,1)",
                        [(account_id, p) for p in data.permissions])
    return {"status": "updated", "permissions": data.permissions}

@app.post("/admin/accounts/{account_id}/suspend")
def suspend_account(account_id: int, authorization: Optional[str] = Header(default=None)):
    admin = admin_user(authorization)
    with db() as con:
        cur = con.execute("UPDATE accounts SET status='suspended' WHERE id=? AND school_id=? AND role!='admin'",
                          (account_id, admin["school_id"]))
        if cur.rowcount == 0:
            raise HTTPException(404, "الحساب غير موجود")
    return {"status": "suspended"}



class AttendanceEvent(BaseModel):
    id: str
    event_type: str
    device_recorded_at: str

class AttendanceSyncIn(BaseModel):
    events: list[AttendanceEvent]

@app.post("/attendance/sync")
def sync_attendance(data: AttendanceSyncIn, authorization: Optional[str] = Header(default=None)):
    user = current_user(authorization)
    if user["status"] != "active":
        raise HTTPException(403, "الحساب غير مفعل")
    accepted = []
    with db() as con:
        for event in data.events[:500]:
            if event.event_type not in {"check_in", "check_out"}:
                continue
            con.execute('''INSERT OR IGNORE INTO attendance_events
              (id,account_id,school_id,event_type,device_recorded_at,server_received_at)
              VALUES(?,?,?,?,?,?)''',
              (event.id, user["id"], user["school_id"], event.event_type,
               event.device_recorded_at, int(time.time())))
            exists = con.execute("SELECT id FROM attendance_events WHERE id=?", (event.id,)).fetchone()
            if exists:
                accepted.append(event.id)
    return {"accepted_ids": accepted}

@app.get("/attendance")
def attendance_list(authorization: Optional[str] = Header(default=None)):
    user = current_user(authorization)
    if user["role"] == "admin":
        with db() as con:
            rows = con.execute('''SELECT e.id,e.account_id,a.display_name,e.event_type,
              e.device_recorded_at,e.server_received_at FROM attendance_events e
              JOIN accounts a ON a.id=e.account_id WHERE e.school_id=?
              ORDER BY e.server_received_at DESC LIMIT 1000''', (user["school_id"],)).fetchall()
        return {"events": [dict(r) for r in rows]}
    with db() as con:
        rows = con.execute('''SELECT id,account_id,event_type,device_recorded_at,server_received_at
          FROM attendance_events WHERE account_id=? ORDER BY server_received_at DESC LIMIT 500''',
          (user["id"],)).fetchall()
    return {"events": [dict(r) for r in rows]}

@app.get("/files")
def list_files(authorization: Optional[str] = Header(default=None)):
    user = current_user(authorization)
    with db() as con:
        if user["role"] == "admin":
            rows = con.execute("SELECT id,owner_id,filename,uploaded_at FROM synced_files WHERE school_id=? ORDER BY uploaded_at DESC",
                               (user["school_id"],)).fetchall()
        else:
            permitted = con.execute("SELECT enabled FROM permissions WHERE account_id=? AND permission='files.read'",
                                     (user["id"],)).fetchone()
            if not permitted or not permitted["enabled"]:
                raise HTTPException(403, "لا تملك صلاحية مشاهدة الملفات")
            rows = con.execute("SELECT id,owner_id,filename,uploaded_at FROM synced_files WHERE school_id=? ORDER BY uploaded_at DESC",
                               (user["school_id"],)).fetchall()
    return {"files": [dict(r) for r in rows]}

@app.post("/files/upload")
async def upload_file(file: UploadFile = File(...), authorization: Optional[str] = Header(default=None)):
    user = current_user(authorization)
    if user["role"] != "admin":
        with db() as con:
            p = con.execute("SELECT enabled FROM permissions WHERE account_id=? AND permission='files.upload'",
                            (user["id"],)).fetchone()
        if not p or not p["enabled"]:
            raise HTTPException(403, "لا تملك صلاحية رفع الملفات")
    safe_name = Path(file.filename or "upload.bin").name[:180]
    stored = secrets.token_hex(16) + Path(safe_name).suffix[:12]
    dest = FILES_DIR / stored
    content = await file.read(20 * 1024 * 1024 + 1)
    if len(content) > 20 * 1024 * 1024:
        raise HTTPException(413, "الحد الأقصى لحجم الملف 20 ميغابايت")
    dest.write_bytes(content)
    with db() as con:
        con.execute("INSERT INTO synced_files(school_id,owner_id,filename,stored_name,uploaded_at) VALUES(?,?,?,?,?)",
                    (user["school_id"], user["id"], safe_name, stored, int(time.time())))
    return {"status": "uploaded", "filename": safe_name}

@app.get("/")
def root():
    return {"name": "SMART SCHOOL ZONE", "version": "0.3.0",
            "note": "Role registration, approval codes, account permissions and school file index starter."}
