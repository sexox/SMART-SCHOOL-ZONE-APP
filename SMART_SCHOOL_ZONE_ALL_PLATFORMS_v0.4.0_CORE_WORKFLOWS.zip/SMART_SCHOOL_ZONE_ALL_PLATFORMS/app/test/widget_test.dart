import 'package:flutter_test/flutter_test.dart';
import 'package:smart_school_zone/app.dart';

void main() {
  testWidgets('dashboard shows app identity', (tester) async {
    await tester.pumpWidget(const SmartSchoolZoneApp());
    expect(find.text('SMART SCHOOL ZONE'), findsOneWidget);
    expect(find.text('الطالب: حسين ماجد'), findsOneWidget);
  });
}
