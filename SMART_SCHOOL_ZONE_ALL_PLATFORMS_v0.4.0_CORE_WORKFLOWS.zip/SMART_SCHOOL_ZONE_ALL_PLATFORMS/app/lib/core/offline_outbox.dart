import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'api.dart';

class OfflineOutbox {
  static const _key = 'ssz_attendance_outbox';

  static Future<List<Map<String, dynamic>>> read() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      return (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    } catch (_) {
      return [];
    }
  }

  static Future<void> record(String type) async {
    final prefs = await SharedPreferences.getInstance();
    final items = await read();
    items.add({
      'id': const Uuid().v4(),
      'event_type': type,
      'device_recorded_at': DateTime.now().toUtc().toIso8601String(),
    });
    await prefs.setString(_key, jsonEncode(items));
  }

  static Future<int> sync(String token) async {
    final prefs = await SharedPreferences.getInstance();
    final items = await read();
    if (items.isEmpty) return 0;
    final result = await Api.post('/attendance/sync', {'events': items}, token: token);
    final accepted = (result['accepted_ids'] as List? ?? []).map((e) => e.toString()).toSet();
    final remaining = items.where((e) => !accepted.contains(e['id'])).toList();
    await prefs.setString(_key, jsonEncode(remaining));
    return accepted.length;
  }
}
