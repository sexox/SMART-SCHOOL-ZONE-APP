import 'dart:convert';
import 'package:http/http.dart' as http;

/// Set this to the HTTPS address of the deployed SMART SCHOOL ZONE API.
/// Never put database passwords, signing keys, or admin bootstrap secrets here.
class Api {
  static const baseUrl = String.fromEnvironment(
    'SSZ_API_URL',
    defaultValue: 'http://10.0.2.2:8000',
  );

  static Future<Map<String, dynamic>> post(
    String path, Map<String, dynamic> body, {String? token}
  ) async {
    final response = await http.post(
      Uri.parse('$baseUrl$path'),
      headers: {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      },
      body: jsonEncode(body),
    );
    final data = response.body.isEmpty
        ? <String, dynamic>{}
        : jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['detail'] ?? 'تعذر تنفيذ الطلب');
    }
    return data;
  }

  static Future<Map<String, dynamic>> get(String path, String token) async {
    final response = await http.get(
      Uri.parse('$baseUrl$path'),
      headers: {'Authorization': 'Bearer $token'},
    );
    final data = response.body.isEmpty
        ? <String, dynamic>{}
        : jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['detail'] ?? 'تعذر تحميل البيانات');
    }
    return data;
  }

  static Future<Map<String, dynamic>> put(
    String path, Map<String, dynamic> body, String token
  ) async {
    final response = await http.put(
      Uri.parse('$baseUrl$path'),
      headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      body: jsonEncode(body),
    );
    final data = response.body.isEmpty ? <String, dynamic>{} : jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['detail'] ?? 'تعذر تنفيذ الطلب');
    }
    return data;
  }
}
