import 'package:flutter/material.dart';
import 'features/auth/role_entry_page.dart';

class SmartSchoolZoneApp extends StatelessWidget {
  const SmartSchoolZoneApp({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF071426);
    return MaterialApp(
      title: 'SMART SCHOOL ZONE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF42D9F5),
          brightness: Brightness.dark,
          surface: const Color(0xFF10243B),
        ),
        useMaterial3: true,
      ),
      home: const RoleEntryPage(),
    );
  }
}
