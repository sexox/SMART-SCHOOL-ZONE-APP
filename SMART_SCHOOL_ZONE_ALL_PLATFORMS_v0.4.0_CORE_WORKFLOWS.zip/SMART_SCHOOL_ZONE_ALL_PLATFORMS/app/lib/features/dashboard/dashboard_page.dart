import 'package:flutter/material.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('SMART SCHOOL ZONE'),
          backgroundColor: Colors.transparent,
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF163B5B), Color(0xFF10243B)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(color: const Color(0x5542D9F5)),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('مرحباً بك', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
                    SizedBox(height: 8),
                    Text('منصة إدارة المدرسة والحضور والتواصل'),
                    SizedBox(height: 16),
                    Text('نسخة تأسيسية — بانتظار ربط الخادم وتفعيل الحساب'),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const _FeatureTile(icon: Icons.how_to_reg, title: 'الحضور والانصراف', subtitle: 'تسجيل محلي ومزامنة عند عودة الإنترنت'),
              const _FeatureTile(icon: Icons.admin_panel_settings, title: 'إدارة الحسابات', subtitle: 'طلبات التسجيل وموافقة المدير'),
              const _FeatureTile(icon: Icons.analytics_outlined, title: 'التقارير والإحصائيات', subtitle: 'قيد التطوير والربط بالخادم'),
              const _FeatureTile(icon: Icons.language, title: 'اللغات', subtitle: 'العربية، الإنجليزية، الإسبانية، الألمانية'),
              const SizedBox(height: 20),
              const Text('حول التطبيق', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              const Text('الطالب: حسين ماجد'),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFF10243B).withOpacity(.88),
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(color: Color(0x3342D9F5)),
      ),
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF42D9F5), size: 28),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
      ),
    );
  }
}
