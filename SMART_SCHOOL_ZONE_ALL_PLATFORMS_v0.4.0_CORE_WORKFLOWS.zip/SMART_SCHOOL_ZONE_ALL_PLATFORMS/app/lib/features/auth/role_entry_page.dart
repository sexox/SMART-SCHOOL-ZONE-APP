import 'package:flutter/material.dart';
import 'registration_page.dart';
import 'login_page.dart';

class RoleEntryPage extends StatelessWidget {
  const RoleEntryPage({super.key});

  @override
  Widget build(BuildContext context) {
    final roles = [
      ('admin', 'مدير المدرسة', Icons.admin_panel_settings, 'إنشاء المدرسة وإدارة الحسابات'),
      ('teacher', 'مدرس', Icons.cast_for_education, 'إنشاء حساب وطلب كود ربط'),
      ('student', 'طالب', Icons.school, 'إنشاء حساب والانضمام للمدرسة'),
      ('staff', 'موظف', Icons.badge, 'إنشاء حساب وطلب موافقة المدير'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('SMART SCHOOL ZONE')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 18),
            const Text('مرحباً بك', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('اختر نوع حسابك للبدء', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 24),
            for (final role in roles)
              Card(
                color: const Color(0xFF10243B),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                  side: const BorderSide(color: Color(0x5542D9F5)),
                ),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: Icon(role.$3, color: const Color(0xFF42D9F5), size: 32),
                  title: Text(role.$2, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(role.$4),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => RegistrationPage(role: role.$1, roleTitle: role.$2)),
                  ),
                ),
              ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())),
              icon: const Icon(Icons.login),
              label: const Text('لدي حساب — تسجيل الدخول'),
            ),
            const SizedBox(height: 16),
            const Text(
              'ملاحظة: حساب المدير الأول يحتاج رمز تهيئة سرياً يضبطه مسؤول النظام على الخادم. لا يمكن لأي مستخدم منح نفسه صلاحية المدير.',
              style: TextStyle(color: Colors.white60, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
