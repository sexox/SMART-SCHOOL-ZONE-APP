import 'package:flutter/material.dart';
import '../../core/api.dart';
import '../home/account_home_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false;
  String? error;

  Future<void> login() async {
    setState(() { busy = true; error = null; });
    try {
      final data = await Api.post('/auth/login', {
        'email': email.text.trim(),
        'password': password.text,
      });
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => AccountHomePage(
          token: data['access_token'],
          role: data['role'],
          name: data['display_name'],
        ),
      ));
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تسجيل الدخول')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('مرحباً بعودتك', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      const SizedBox(height: 20),
      TextField(controller: email, keyboardType: TextInputType.emailAddress,
        decoration: const InputDecoration(labelText: 'البريد الإلكتروني')),
      const SizedBox(height: 12),
      TextField(controller: password, obscureText: true,
        decoration: const InputDecoration(labelText: 'كلمة المرور')),
      const SizedBox(height: 18),
      FilledButton(onPressed: busy ? null : login,
        child: Text(busy ? 'جارٍ الدخول...' : 'دخول')),
      if (error != null) Padding(padding: const EdgeInsets.only(top: 12),
        child: Text(error!, style: const TextStyle(color: Colors.redAccent))),
    ]),
  );
}
