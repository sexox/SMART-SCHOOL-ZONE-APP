import 'package:flutter/material.dart';
import '../../core/api.dart';
import '../home/account_home_page.dart';

class RegistrationPage extends StatefulWidget {
  const RegistrationPage({super.key, required this.role, required this.roleTitle});
  final String role;
  final String roleTitle;

  @override
  State<RegistrationPage> createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final school = TextEditingController();
  final bootstrap = TextEditingController();
  bool busy = false;
  String? resultCode;
  String? error;

  Future<void> submit() async {
    setState(() { busy = true; error = null; resultCode = null; });
    try {
      final data = await Api.post('/auth/register', {
        'display_name': name.text.trim(),
        'email': email.text.trim(),
        'password': password.text,
        'role': widget.role,
        'school_name': school.text.trim(),
        if (widget.role == 'admin') 'bootstrap_key': bootstrap.text,
      });
      if (!mounted) return;
      if (widget.role == 'admin' && data['access_token'] != null) {
        Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => AccountHomePage(token: data['access_token'], role: 'admin', name: name.text.trim()),
        ));
      } else {
        setState(() => resultCode = data['link_code']?.toString());
      }
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    name.dispose(); email.dispose(); password.dispose(); school.dispose(); bootstrap.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إنشاء حساب — ${widget.roleTitle}')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _field(name, 'الاسم الكامل'),
          _field(email, 'البريد الإلكتروني', type: TextInputType.emailAddress),
          _field(password, 'كلمة المرور', secret: true),
          if (widget.role == 'admin') ...[
            _field(school, 'اسم المدرسة'),
            _field(bootstrap, 'رمز تهيئة المدير', secret: true),
          ],
          const SizedBox(height: 16),
          FilledButton(
            onPressed: busy ? null : submit,
            child: Text(busy ? 'جارٍ الإرسال...' : 'إنشاء الحساب'),
          ),
          if (error != null) Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(error!, style: const TextStyle(color: Colors.redAccent)),
          ),
          if (resultCode != null) ...[
            const SizedBox(height: 24),
            const Text('تم إنشاء طلبك. أرسل كود الربط التالي إلى مدير المدرسة:'),
            const SizedBox(height: 12),
            SelectableText(resultCode!, textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 30, letterSpacing: 5, fontWeight: FontWeight.bold, color: Color(0xFF42D9F5))),
            const SizedBox(height: 8),
            const Text('سيبقى حسابك بانتظار موافقة المدير. احتفظ بالكود ولا تشاركه إلا مع مدير مدرستك.'),
          ],
        ],
      ),
    );
  }

  Widget _field(TextEditingController c, String label, {bool secret = false, TextInputType? type}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        obscureText: secret,
        keyboardType: type,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: const Color(0xFF10243B),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
        ),
      ),
    );
  }
}
