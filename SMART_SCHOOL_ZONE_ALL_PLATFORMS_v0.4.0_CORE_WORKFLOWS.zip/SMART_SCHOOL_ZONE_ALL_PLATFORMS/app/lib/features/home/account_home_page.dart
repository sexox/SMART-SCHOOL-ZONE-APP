import 'package:flutter/material.dart';
import '../../core/api.dart';
import '../../core/offline_outbox.dart';

const permissionLabels = <String, String>{
  'attendance.read': 'مشاهدة سجل الحضور',
  'attendance.write': 'تسجيل الحضور والانصراف',
  'students.read': 'مشاهدة الطلاب',
  'students.manage': 'إدارة الطلاب',
  'reports.read': 'مشاهدة التقارير',
  'reports.export': 'تصدير التقارير',
  'files.read': 'مشاهدة ملفات المدرسة',
  'files.upload': 'رفع الملفات',
  'classes.manage': 'إدارة الصفوف',
};

class AccountHomePage extends StatefulWidget {
  const AccountHomePage({super.key, required this.token, required this.role, required this.name});
  final String token;
  final String role;
  final String name;

  @override
  State<AccountHomePage> createState() => _AccountHomePageState();
}

class _AccountHomePageState extends State<AccountHomePage> {
  final code = TextEditingController();
  List<dynamic> accounts = [];
  List<dynamic> files = [];
  List<dynamic> attendanceEvents = [];
  String? message;
  bool busy = false;
  int queued = 0;

  bool get isAdmin => widget.role == 'admin';

  @override
  void initState() {
    super.initState();
    refreshQueue();
    if (isAdmin) loadAccounts();
  }

  Future<void> refreshQueue() async {
    final items = await OfflineOutbox.read();
    if (mounted) setState(() => queued = items.length);
  }

  Future<void> attendance(String type) async {
    await OfflineOutbox.record(type);
    await refreshQueue();
    try {
      final count = await OfflineOutbox.sync(widget.token);
      await refreshQueue();
      setState(() => message = count > 0 ? 'تمت مزامنة $count عملية' : 'تم حفظ العملية');
    } catch (_) {
      setState(() => message = 'حُفظت العملية محلياً وستتم مزامنتها عند عودة الإنترنت');
    }
  }

  Future<void> syncNow() async {
    try {
      final count = await OfflineOutbox.sync(widget.token);
      await refreshQueue();
      setState(() => message = 'اكتملت المزامنة: $count عملية');
    } catch (e) {
      setState(() => message = 'تعذرت المزامنة حالياً: $e');
    }
  }

  Future<void> loadAccounts() async {
    setState(() => busy = true);
    try {
      final data = await Api.get('/admin/accounts', widget.token);
      setState(() { accounts = data['accounts'] as List<dynamic>? ?? []; message = null; });
    } catch (e) {
      setState(() => message = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> approve() async {
    try {
      final data = await Api.post('/admin/approve-code', {'code': code.text.trim()}, token: widget.token);
      setState(() => message = 'تم اعتماد وربط الحساب: ${data['display_name']}');
      code.clear();
      await loadAccounts();
    } catch (e) {
      setState(() => message = e.toString());
    }
  }

  Future<void> loadAttendance() async {
    try {
      final data = await Api.get('/attendance', widget.token);
      setState(() => attendanceEvents = data['events'] as List<dynamic>? ?? []);
    } catch (e) {
      setState(() => message = e.toString());
    }
  }

  Future<void> loadFiles() async {
    try {
      final data = await Api.get('/files', widget.token);
      setState(() => files = data['files'] as List<dynamic>? ?? []);
    } catch (e) {
      setState(() => message = e.toString());
    }
  }

  Future<void> editPermissions(Map<String, dynamic> account) async {
    final selected = <String>{};
    final existing = account['permissions'];
    if (existing is Map) {
      for (final entry in existing.entries) {
        if (entry.value == true) selected.add(entry.key.toString());
      }
    }
    final result = await showDialog<Set<String>>(
      context: context,
      builder: (context) {
        final draft = Set<String>.from(selected);
        return StatefulBuilder(builder: (context, setDialog) => AlertDialog(
          title: Text('صلاحيات ${account['display_name']}'),
          content: SizedBox(
            width: 420,
            child: SingleChildScrollView(child: Column(
              mainAxisSize: MainAxisSize.min,
              children: permissionLabels.entries.map((e) => CheckboxListTile(
                value: draft.contains(e.key),
                title: Text(e.value),
                onChanged: (v) => setDialog(() {
                  if (v == true) { draft.add(e.key); } else { draft.remove(e.key); }
                }),
              )).toList(),
            )),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(context, draft), child: const Text('حفظ الصلاحيات')),
          ],
        ));
      },
    );
    if (result == null) return;
    try {
      await Api.put('/admin/accounts/${account['id']}/permissions',
        {'permissions': result.toList()}, widget.token);
      setState(() => message = 'تم تحديث الصلاحيات');
      await loadAccounts();
    } catch (e) {
      setState(() => message = e.toString());
    }
  }

  Future<void> suspend(Map<String, dynamic> account) async {
    try {
      await Api.post('/admin/accounts/${account['id']}/suspend', {}, token: widget.token);
      setState(() => message = 'تم إيقاف الحساب');
      await loadAccounts();
    } catch (e) {
      setState(() => message = e.toString());
    }
  }

  @override
  void dispose() { code.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SMART SCHOOL ZONE')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Text('أهلاً ${widget.name}', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      Text(isAdmin ? 'لوحة إدارة المدرسة' : 'حساب ${widget.role}'),
      const SizedBox(height: 18),
      if (!isAdmin) ...[
        Row(children: [
          Expanded(child: FilledButton.icon(
            onPressed: () => attendance('check_in'),
            icon: const Icon(Icons.login), label: const Text('تسجيل الدخول'),
          )),
          const SizedBox(width: 10),
          Expanded(child: FilledButton.tonalIcon(
            onPressed: () => attendance('check_out'),
            icon: const Icon(Icons.logout), label: const Text('تسجيل المغادرة'),
          )),
        ]),
        const SizedBox(height: 8),
        Card(child: ListTile(
          leading: const Icon(Icons.sync),
          title: Text('عمليات بانتظار المزامنة: $queued'),
          trailing: IconButton(onPressed: syncNow, icon: const Icon(Icons.refresh)),
        )),
      ],
      if (isAdmin) ...[
        const Text('اعتماد حساب جديد', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: code, decoration: const InputDecoration(labelText: 'أدخل كود الربط')),
        const SizedBox(height: 8),
        FilledButton(onPressed: approve, child: const Text('اعتماد وربط الحساب')),
        const SizedBox(height: 22),
        Row(children: [
          const Expanded(child: Text('حسابات المدرسة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold))),
          IconButton(onPressed: loadAccounts, icon: const Icon(Icons.refresh)),
        ]),
        if (busy) const Center(child: CircularProgressIndicator()),
        for (final raw in accounts)
          if (raw is Map) Card(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(children: [
                ListTile(
                  title: Text('${raw['display_name'] ?? ''}'),
                  subtitle: Text('${raw['email'] ?? ''} • ${raw['role'] ?? ''} • ${raw['status'] ?? ''}'),
                ),
                if (raw['role'] != 'admin')
                  Wrap(alignment: WrapAlignment.end, children: [
                    TextButton.icon(
                      onPressed: () => editPermissions(Map<String, dynamic>.from(raw)),
                      icon: const Icon(Icons.tune), label: const Text('الصلاحيات'),
                    ),
                    TextButton.icon(
                      onPressed: () => suspend(Map<String, dynamic>.from(raw)),
                      icon: const Icon(Icons.block), label: const Text('إيقاف'),
                    ),
                  ]),
              ]),
            ),
          ),
        const SizedBox(height: 18),
        Row(children: [
          const Expanded(child: Text('سجل الحضور والانصراف', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold))),
          IconButton(onPressed: loadAttendance, icon: const Icon(Icons.event_note)),
        ]),
        for (final e in attendanceEvents)
          ListTile(
            leading: Icon(e['event_type'] == 'check_in' ? Icons.login : Icons.logout),
            title: Text('${e['display_name'] ?? 'حساب'} — ${e['event_type'] == 'check_in' ? 'دخول' : 'مغادرة'}'),
            subtitle: Text('${e['device_recorded_at']}'),
          ),
        const SizedBox(height: 18),
        Row(children: [
          const Expanded(child: Text('ملفات المدرسة المتزامنة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold))),
          IconButton(onPressed: loadFiles, icon: const Icon(Icons.folder_open)),
        ]),
        for (final f in files)
          ListTile(
            leading: const Icon(Icons.insert_drive_file),
            title: Text('${f['filename'] ?? 'ملف'}'),
            subtitle: Text('صاحب الملف: ${f['owner_id']}'),
          ),
      ],
      if (message != null) Padding(
        padding: const EdgeInsets.only(top: 14),
        child: Text(message!, style: const TextStyle(color: Color(0xFF42D9F5))),
      ),
    ]),
  );
}
