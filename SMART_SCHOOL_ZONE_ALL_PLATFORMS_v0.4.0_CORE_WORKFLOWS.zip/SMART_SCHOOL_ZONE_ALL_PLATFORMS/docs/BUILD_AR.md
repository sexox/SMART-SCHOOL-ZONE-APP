# البناء

## Flutter محلياً
```bash
cd app
flutter pub get
flutter create . --platforms=android,ios,windows
flutter analyze
flutter test
```

## Android
```bash
cd app
flutter build apk --release
```

## Windows
```powershell
cd app
flutter build windows --release
```
يتطلب Windows وVisual Studio مع Desktop development with C++.

## iOS
```bash
cd app
flutter build ios --release
```
يتطلب macOS وXcode. لإنتاج IPA قابل للتوزيع يلزم إعداد توقيع Apple وprovisioning.
